/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'en', {
	label: 'Copy Formatting',
	notification: {
		copied: 'Formatting copied',
		applied: 'Formatting applied',
		canceled: 'Formatting canceled',
		failed: 'Formatting failed. You cannot apply styles without copying them first.'
	}
} );
