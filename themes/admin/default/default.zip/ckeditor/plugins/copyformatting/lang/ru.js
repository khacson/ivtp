/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'ru', {
	label: 'Копировать форматирование',
	notification: {
		copied: 'Форматирование скопировано',
		applied: 'Форматирование применено',
		canceled: 'Форматирование отменен',
		failed: 'Formatting failed. You cannot apply styles without copying them first.' // MISSING
	}
} );
